exports.foo = () => true;
exports.bar = 4;
