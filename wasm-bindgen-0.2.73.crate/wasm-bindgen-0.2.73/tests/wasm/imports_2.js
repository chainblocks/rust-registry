exports.same_name_from_import = (a) => a * 4;

exports.same_js_namespace_from_module = {
  func_from_module_2_same_js_namespace: (a) => a * 6
}