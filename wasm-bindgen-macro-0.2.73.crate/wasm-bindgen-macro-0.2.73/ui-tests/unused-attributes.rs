use wasm_bindgen::prelude::*;

struct A;

#[wasm_bindgen]
impl A {
    #[wasm_bindgen(method)]
    #[wasm_bindgen(method)]
    pub fn foo() {
    }
}

fn main() {}
