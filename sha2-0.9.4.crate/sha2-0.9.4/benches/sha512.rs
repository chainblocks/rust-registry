#![no_std]
#![feature(test)]

digest::bench!(sha2::Sha512);
