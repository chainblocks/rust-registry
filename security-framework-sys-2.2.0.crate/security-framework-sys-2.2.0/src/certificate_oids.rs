use core_foundation_sys::string::CFStringRef;

extern "C" {
    pub static kSecOIDX509V1SignatureAlgorithm: CFStringRef;
}
