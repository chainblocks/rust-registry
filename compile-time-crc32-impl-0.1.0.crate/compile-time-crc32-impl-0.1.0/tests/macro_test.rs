use compile_time_crc32::*;

fn main() {
    
}
